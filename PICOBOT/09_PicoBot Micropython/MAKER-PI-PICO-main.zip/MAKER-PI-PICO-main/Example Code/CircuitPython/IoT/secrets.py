# Secret Keys.

secrets = {
    "ssid"                     : "my_wifi_ssid",                                    
    "password"                 : "my_wifi_password",
    "blynk_auth_token"         : "my_blynk_auth_token",
    "thingspeak_write_api_key" : "my_thingspeak_write_api_key",
    "telegram_bot_token"       : "my_telegram_bot_token",
    "telegram_chat_id"         : "my_telegram_chat_id",
    "aio_username"             : "my_adafruitio_username",
    "aio_key"                  : "my_adafruitio_key"
}
